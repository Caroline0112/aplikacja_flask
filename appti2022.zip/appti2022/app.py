from flask import Flask, flash, render_template
from flask import request

import io
import base64
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon

app = Flask(__name__)
app.secret_key="a"

@app.route('/')
def home():
    return render_template("home.html")

@app.route('/subpage_one')
def subpage_one():
    return render_template("subpage_one.html")

@app.route('/subpage_two')
def subpage_two():
    return render_template('subpage_two.html')


def rysuj():
    img = io.BytesIO()
    m =[]
    a = float(request.form['pierwszy_wyraz'])
    q = float(request.form['iloraz'])
    n = int(request.form['ilość_wyrazów'])
    y = np.linspace(1,n,n)
    i = 1
    while i<=n:
        cr = a*(q**(i-1))
        m.append(cr)
        i = i+1
    plt.scatter(y,m)
    plt.xlabel("wyrazy")
    plt.ylabel("wartości")
    plt.title("szereg gometryczny")

    plt.savefig(img, format='png')
    img.seek(0)
    url = base64.b64encode(img.getvalue()).decode()
    plt.close()
    return 'data:image/png;base64,{}'.format(url)

@app.route("/docount", methods=["POST", "GET"])
def licz():
    a = float(request.form['pierwszy_wyraz'])
    q = float(request.form['iloraz'])
    sum = a/(1-q)
    flash ("Suma szeregu to "+str(sum))
    return render_template("subpage_two.html")
    
    
@app.route("/plot", methods=["POST", "GET"])
def plot():
    Ploting=False
    return render_template("subpage_two.html", Ploting=Ploting)

@app.route("/doplot", methods=["POST", "GET"])
def doplot():
    plot=rysuj()
    Ploting=True
    return render_template("subpage_two.html", plot=plot, Ploting=Ploting)
